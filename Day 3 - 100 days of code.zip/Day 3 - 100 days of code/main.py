"""
Program to check whether a given number is even or odd.
Introduction to if-else block and modulo operator.
"""

number = int(input("Enter the number: "))
if number % 2 == 0:
    print("Number is Even")
else:
    print("Number is Odd")